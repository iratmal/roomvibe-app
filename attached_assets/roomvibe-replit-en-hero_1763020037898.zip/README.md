# RoomVibe Landing (Turquoise)
Single-accent (turquoise) modern landing for RoomVibe — no theme variants.

## Run
npm install
npm run dev

## Build
npm run build
npm run preview
